<?php $__env->startSection('content'); ?>


<div class="page-header">
   <div class="row">
    <div class="col-sm-10"> <h4>Product</h4></div>
  </div>
         
          
  </div>

<div class="container">
<div class="row">
  <div class="col-sm-6">
    <table class="table table-condensed table-striped table-bordered">
      <tbody>
        <tr>
          <th>Name</th>
          <td><?php echo e($product->product_name); ?></td>
        </tr>
         <tr>
          <th>Category</th>
          <td><?php echo e($product->category->category_name); ?></td>
        </tr>
           <tr>
          <th>Product description</th>
          <td><?php echo e($product->product_desc); ?></td>
        </tr>
          <th>Volume</th>
          <td><?php echo e($product->volume_size); ?></td>
        </tr>
          <tr>
          <th>Company</th>
          <td><?php echo e($product->company->company_name); ?></td>
        </tr>
         <tr>
        
      </tbody>
    </table>
    <form action="/product/<?php echo e($product->id); ?>" method="POST">
      <?php echo e(csrf_field()); ?>

      <input type="hidden" name="_method" value="DELETE">
      <div class="btn btn-group">
        <a href="/product/<?php echo e($product->id); ?>/edit" class="btn btn-sm btn-warning"><i class="fa fa-edit"></i> Edit</a>
        <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> Delete </button>
         <a href="/product" class="btn btn-sm btn-success"><i class="fa fa-arrow-left" aria-hidden="true"></i>Back</a>
      </div>
    </form>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>