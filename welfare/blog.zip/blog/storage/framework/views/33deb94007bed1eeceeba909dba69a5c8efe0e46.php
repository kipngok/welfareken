<?php $__env->startSection('content'); ?>
    
<div class="container" >
    <div class="row mt-3">
        <div class="col-sm-6">
            <div class="alert alert-info mt-3"> You are logged in as <?php echo e(Auth::user()->name); ?></div>
        </div>
    </div>

        <div class="row">
            <div class="col-sm-6">
                
                <?php if(Auth::user()->is_admin ==1): ?>
        <div class="card mt-3">
            <div class="card-header"><h4>Summary</h4></div>
             <div class="card-body">
            <table class="table table-condensed table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Total Income</th>
                        </tr>
                    </thead>
                    <tbody>
                       
                        <tr>
                            
                            <td>KSH.<?php echo e($totalamount); ?></td>
                        </tr>
                        
                    </tbody>
                </table>
        </div>
       </div>
       <?php endif; ?>
   </div>
   <div class="col-sm-4">
       <div class="card mt-3">
        <div class="card-header">
          <h4>Total Product</h4></div>
        <div class="card-body">
            <table class="table table-condensed table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Products</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e($totalproducts); ?></td>
                        </tr>
                        
                    </tbody>
                </table>
        </div>
       </div>
   </div>
</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>