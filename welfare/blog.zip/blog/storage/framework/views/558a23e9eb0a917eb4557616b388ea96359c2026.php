<?php $__env->startSection('content'); ?>


<div class="page-header">
   <div class="row">
    <div class="col-sm-10"><h4>Create Product</h4></div>
  </div>
  </div>
<div class="container">
<div class="row">
  <div class="col-sm-6">
    <form action="/product" method="POST">
      <?php echo e(csrf_field()); ?>

      <div class="form-group">
        <label>Product name</label>
        <input type="text" name="product_name" class="form-control">
      </div>
       <div class="form-group">
          <label>Category</label>
          <!-- <select class="form-control" name="category_id"> -->
           <select class="form-control" name="category_id">
          <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          </div>
       <div class="form-group">
        <label>Product description</label>
        <input type="text" name="product_desc" class="form-control">
      </div>
         <div class="form-group">
       
        <label>Company</label>
        <select class="form-control" name="company_id">
          <?php $__currentLoopData = $companys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($company->id); ?>"><?php echo e($company->company_name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
       <div class="form-group">
        <label>Product volume</label>
        <input type="text" name="volume_size" class="form-control">
      </div>


      <div class="form-group">
        <button type="submit" class="btn btn-sm btn-success">Save</button>
      </div>
    </form>

  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>