<ul class="sidebar-menu" style="list-style: none; padding: 0px;">
      <li><a href="/" class="navio"><i class="fa fa-tachometer" aria-hidden="true" fa-3x></i>&nbsp; Dashboard</a></li>
        <li data-toggle="collapse" data-target="#products" class="navio"><i class="fa fa-product-hunt" aria-hidden="true"fa-3x></i>&nbsp; Products
   <span class="arrow"></span></li>
    <ul class="sub-menu collapse" id="products">
     <a href="/product" class="navio" style="width: 110% ; margin-left: -10%"><i class="fa fa-product-hunt" aria-hidden="true"fa-3x></i>&nbsp;Catalog
     </a>
     <a href="/category" class="navio" style="width: 110% ; margin-left: -10%"><i class="fa fa-tag" aria-hidden="true"fa-3x></i>&nbsp;
      Categories
     </a>
      <a href="/code" class="navio" style="width: 110% ; margin-left:-10%"><i class="fa fa-code" aria-hidden="true"fa-3x></i>&nbsp;
     Code
    </a>
       </ul>
    
     
       <li><a href="/notification" class="navio"><i class="fa fa-bell" aria-hidden="true" fa-3x></i>&nbsp;Notification</a></li>
      

<li  data-toggle="collapse" data-target="#report" class="navio">
       <i class="fa fa-file" aria-hidden="true" fa-3x></i>&nbsp;
      Report
      <span class="arrow"></span>
      </li>
      <ul class="sub-menu collapse" id="report">
      <a href="/income" class="navio" style="width: 110% ; margin-left: -10%"><i class="fa fa-exchange" aria-hidden="true" fa-3x></i>&nbsp;Transactions</a>
      <a href="/active" class="navio" style="width: 110% ; margin-left: -10%"><i  class="fa fa-rocket" aria-hidden="true" fa-3x></i>&nbsp;Active codes</a>
       <a href="/inactive" class="navio" style="width: 110% ; margin-left: -10%"><i class="fa fa-user" aria-hidden="true" fa-3x></i>&nbsp;Inactive codes</a>
         <a href="/notification" class="navio" style="width: 110% ; margin-left: -10%"><i class="fa fa-user" aria-hidden="true" fa-3x></i>&nbsp;Invalid codes</a>
       </ul>




      <!-- <li><a href="/customer" class="navio"><i class="fa fa-users" aria-hidden="true"fa-3x></i>&nbsp;Customer</a></li> -->
      <li  data-toggle="collapse" data-target="#facilities" class="navio">
        <i class="fa fa-cog" aria-hidden="true" fa-3x></i>&nbsp;
      Settings 
      <span class="arrow"></span>
      </li>
      <ul class="sub-menu collapse" id="facilities">
      <a href="/company" class="navio" style="width: 110% ; margin-left: -10%"><i class="fa fa-building-o" aria-hidden="true" fa-3x></i>&nbsp;Company</a>
      <a href="/user" class="navio" style="width: 110% ; margin-left: -10%"><i class="fa fa-user" aria-hidden="true" fa-3x></i>&nbsp;Users</a>
       </ul>
       </ul>
